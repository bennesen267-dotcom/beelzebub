package dev.hvhclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonArray;
import dev.hvhclient.ClientMain;
import dev.hvhclient.friend.FriendManager;
import dev.hvhclient.macro.MacroManager;
import dev.hvhclient.module.Module;
import dev.hvhclient.module.ModuleManager;
import dev.hvhclient.setting.Setting;
import dev.hvhclient.theme.Theme;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Modül durumlarını, ayarları ve temayı config/beelzebub.json dosyasına kaydeder/yükler. */
public class ConfigManager {
    private static final Logger LOG = LoggerFactory.getLogger(ClientMain.NAME);
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("beelzebub.json");
    }

    public static void save() {
        JsonObject root = new JsonObject();
        root.addProperty("theme", Theme.current().name());

        JsonObject modules = new JsonObject();
        for (Module m : ModuleManager.getModules()) {
            JsonObject mo = new JsonObject();
            mo.addProperty("enabled", m.isEnabled());
            mo.addProperty("bind", m.getKey());
            JsonObject so = new JsonObject();
            for (Setting s : m.getSettings()) so.add(s.getName(), s.save());
            mo.add("settings", so);
            modules.add(m.getName(), mo);
        }
        root.add("modules", modules);

        JsonArray friends = new JsonArray();
        for (String f : FriendManager.list()) friends.add(f);
        root.add("friends", friends);

        JsonArray macros = new JsonArray();
        for (MacroManager.Macro m : MacroManager.list()) {
            JsonObject mo = new JsonObject();
            mo.addProperty("name", m.name);
            mo.addProperty("key", m.key);
            mo.addProperty("message", m.message);
            macros.add(mo);
        }
        root.add("macros", macros);

        try {
            Files.writeString(file(), GSON.toJson(root));
        } catch (IOException e) {
            LOG.error("Config kaydedilemedi", e);
        }
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) return;
        try {
            JsonObject root = JsonParser.parseString(Files.readString(f)).getAsJsonObject();

            if (root.has("theme")) {
                try {
                    Theme.set(Theme.valueOf(root.get("theme").getAsString()));
                } catch (IllegalArgumentException ignored) {
                    // bilinmeyen tema: varsayılan kalır
                }
            }

            if (root.has("friends") && root.get("friends").isJsonArray()) {
                FriendManager.clear();
                for (var e : root.getAsJsonArray("friends")) FriendManager.add(e.getAsString());
            }
            if (root.has("macros") && root.get("macros").isJsonArray()) {
                MacroManager.clear();
                for (var e : root.getAsJsonArray("macros")) {
                    try {
                        JsonObject mo = e.getAsJsonObject();
                        MacroManager.add(mo.get("name").getAsString(), mo.get("key").getAsInt(),
                                mo.get("message").getAsString());
                    } catch (RuntimeException ex) {
                        LOG.warn("Makro yüklenemedi");
                    }
                }
            }

            if (!root.has("modules")) return;
            JsonObject modules = root.getAsJsonObject("modules");
            for (Module m : ModuleManager.getModules()) {
                if (!modules.has(m.getName())) continue;
                JsonObject mo = modules.getAsJsonObject(m.getName());

                if (mo.has("settings")) {
                    JsonObject so = mo.getAsJsonObject("settings");
                    for (Setting s : m.getSettings()) {
                        if (!so.has(s.getName())) continue;
                        try {
                            s.load(so.get(s.getName()));
                        } catch (RuntimeException e) {
                            LOG.warn("Ayar yüklenemedi: {}.{}", m.getName(), s.getName());
                        }
                    }
                }
                if (mo.has("bind")) m.setKey(mo.get("bind").getAsInt());
                // Ayarlar yüklendikten sonra aç ki onEnable güncel ayarları görsün.
                if (mo.has("enabled")) m.setEnabled(mo.get("enabled").getAsBoolean());
            }
        } catch (IOException | RuntimeException e) {
            LOG.error("Config yüklenemedi", e);
        }
    }
}
