package dev.hvhclient.command;

import dev.hvhclient.config.ConfigManager;
import dev.hvhclient.friend.FriendManager;
import dev.hvhclient.macro.MacroManager;
import dev.hvhclient.module.Module;
import dev.hvhclient.module.ModuleManager;
import dev.hvhclient.module.impl.CommandsModule;
import dev.hvhclient.util.ChatUtil;
import net.minecraft.client.MinecraftClient;

import java.util.List;

/** Sohbetten prefix ile yazılan client komutları. true dönerse mesaj sunucuya gönderilmez. */
public class CommandManager {

    public static boolean handle(String message) {
        CommandsModule mod = ModuleManager.commands();
        if (mod == null || !mod.isEnabled()) return false;

        String prefix = mod.prefix();
        if (!message.startsWith(prefix)) return false;
        String line = message.substring(prefix.length()).trim();
        // ".." veya "-_-" gibi mesajlar komut sayılmaz, normal sohbete gider.
        if (line.isEmpty() || !Character.isLetter(line.charAt(0))) return false;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud != null) mc.inGameHud.getChatHud().addToMessageHistory(message);

        String[] a = line.split("\\s+");
        switch (a[0].toLowerCase()) {
            case "help", "yardim" -> help(prefix);
            case "friend", "friends", "f" -> friend(a, prefix);
            case "macro", "macros" -> macro(a, prefix);
            case "bind" -> bind(a, prefix);
            case "toggle", "t" -> toggle(a, prefix);
            default -> ChatUtil.info("Bilinmeyen komut. " + prefix + "help yaz.");
        }
        ConfigManager.save();
        return true;
    }

    private static void help(String p) {
        ChatUtil.info(p + "friend add|remove <isim> | list | clear");
        ChatUtil.info(p + "macro add <isim> <tuş> <mesaj> | remove <isim> | list | clear");
        ChatUtil.info(p + "bind <modül> <tuş|none>");
        ChatUtil.info(p + "toggle <modül>");
        ChatUtil.info("Tuş örnekleri: g, f6, left.shift, keypad.1. Mesaj / ile başlarsa komut olarak gönderilir.");
    }

    private static void friend(String[] a, String p) {
        String sub = a.length > 1 ? a[1].toLowerCase() : "list";
        switch (sub) {
            case "add" -> {
                if (a.length < 3) { ChatUtil.info("Kullanım: " + p + "friend add <isim>"); return; }
                ChatUtil.info(FriendManager.add(a[2]) ? a[2] + " eklendi." : a[2] + " zaten listede.");
            }
            case "remove", "del" -> {
                if (a.length < 3) { ChatUtil.info("Kullanım: " + p + "friend remove <isim>"); return; }
                ChatUtil.info(FriendManager.remove(a[2]) ? a[2] + " çıkarıldı." : a[2] + " listede yok.");
            }
            case "list" -> {
                List<String> l = FriendManager.list();
                ChatUtil.info(l.isEmpty() ? "Arkadaş listesi boş." : "Arkadaşlar (" + l.size() + "): " + String.join(", ", l));
            }
            case "clear" -> {
                FriendManager.clear();
                ChatUtil.info("Arkadaş listesi temizlendi.");
            }
            default -> ChatUtil.info("Kullanım: " + p + "friend add|remove|list|clear");
        }
    }

    private static void macro(String[] a, String p) {
        String sub = a.length > 1 ? a[1].toLowerCase() : "list";
        switch (sub) {
            case "add" -> {
                if (a.length < 5) { ChatUtil.info("Kullanım: " + p + "macro add <isim> <tuş> <mesaj>"); return; }
                int key = MacroManager.parseKey(a[3]);
                if (key < 0) { ChatUtil.info("Geçersiz tuş: " + a[3]); return; }
                String msg = String.join(" ", java.util.Arrays.copyOfRange(a, 4, a.length));
                MacroManager.add(a[2], key, msg);
                ChatUtil.info("Makro '" + a[2] + "' [" + MacroManager.keyName(key) + "] -> " + msg);
            }
            case "remove", "del" -> {
                if (a.length < 3) { ChatUtil.info("Kullanım: " + p + "macro remove <isim>"); return; }
                ChatUtil.info(MacroManager.remove(a[2]) ? "Makro silindi." : "Böyle bir makro yok.");
            }
            case "list" -> {
                if (MacroManager.list().isEmpty()) { ChatUtil.info("Makro yok."); return; }
                for (MacroManager.Macro m : MacroManager.list()) {
                    ChatUtil.info(m.name + " [" + MacroManager.keyName(m.key) + "] -> " + m.message);
                }
            }
            case "clear" -> {
                MacroManager.clear();
                ChatUtil.info("Tüm makrolar silindi.");
            }
            default -> ChatUtil.info("Kullanım: " + p + "macro add|remove|list|clear");
        }
    }

    private static void bind(String[] a, String p) {
        if (a.length < 3) { ChatUtil.info("Kullanım: " + p + "bind <modül> <tuş|none>"); return; }
        Module m = ModuleManager.getByName(a[1]);
        if (m == null) { ChatUtil.info("Modül bulunamadı: " + a[1]); return; }
        if (a[2].equalsIgnoreCase("none")) {
            m.setKey(-1);
            ChatUtil.info(m.getName() + " bind'i silindi.");
            return;
        }
        int key = MacroManager.parseKey(a[2]);
        if (key < 0) { ChatUtil.info("Geçersiz tuş: " + a[2]); return; }
        m.setKey(key);
        ChatUtil.info(m.getName() + " -> [" + MacroManager.keyName(key) + "]");
    }

    private static void toggle(String[] a, String p) {
        if (a.length < 2) { ChatUtil.info("Kullanım: " + p + "toggle <modül>"); return; }
        Module m = ModuleManager.getByName(a[1]);
        if (m == null) { ChatUtil.info("Modül bulunamadı: " + a[1]); return; }
        m.toggle();
        ChatUtil.info(m.getName() + (m.isEnabled() ? " açıldı." : " kapandı."));
    }
}
