package dev.hvhclient.module.impl;

import dev.hvhclient.friend.FriendManager;
import dev.hvhclient.module.Category;
import dev.hvhclient.module.Module;
import dev.hvhclient.setting.SliderSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AimAssistModule extends Module {
    /** Tick başına dönebileceği maksimum açı (derece). */
    private final SliderSetting speed = add(new SliderSetting("Speed", 1, 20, 5));
    /** 1-7 blok; 8'de sınırsız. */
    private final SliderSetting range = add(new SliderSetting("Range", 1, 8, 4).maxLabel("Infinite"));

    public AimAssistModule() {
        super("AimAssist", Category.COMBAT);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null) return;

        boolean infinite = range.isMax();
        double maxDist = range.get();

        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (e == p || !(e instanceof LivingEntity) || e instanceof ArmorStandEntity) continue;
            if (FriendManager.isFriend(e)) continue;
            LivingEntity living = (LivingEntity) e;
            if (!living.isAlive() || living.isSpectator()) continue;
            double d = p.distanceTo(living);
            if (!infinite && d > maxDist) continue;
            if (d < bestDist) {
                best = living;
                bestDist = d;
            }
        }
        if (best == null) return;

        Vec3d from = p.getEyePos();
        Vec3d to = best.getBoundingBox().getCenter();
        double dx = to.x - from.x, dy = to.y - from.y, dz = to.z - from.z;

        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz)));

        float step = speed.get();
        float yawDiff = MathHelper.wrapDegrees(targetYaw - p.getYaw());
        float pitchDiff = targetPitch - p.getPitch();

        p.setYaw(p.getYaw() + MathHelper.clamp(yawDiff, -step, step));
        p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(pitchDiff, -step, step), -90f, 90f));
    }
}
