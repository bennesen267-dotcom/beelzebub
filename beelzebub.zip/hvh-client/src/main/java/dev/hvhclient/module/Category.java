package dev.hvhclient.module;

public enum Category {
    COMBAT("Combat"),
    RENDER("Render"),
    MISC("Misc");

    public final String label;

    Category(String label) {
        this.label = label;
    }
}
