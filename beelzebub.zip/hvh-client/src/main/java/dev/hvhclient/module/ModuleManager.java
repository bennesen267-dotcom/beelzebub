package dev.hvhclient.module;

import dev.hvhclient.module.impl.AimAssistModule;
import dev.hvhclient.module.impl.AutoInventoryTotemModule;
import dev.hvhclient.module.impl.CommandsModule;
import dev.hvhclient.module.impl.FriendsModule;
import dev.hvhclient.module.impl.HudModule;
import dev.hvhclient.module.impl.MacroModule;
import dev.hvhclient.module.impl.NametagsModule;
import dev.hvhclient.module.impl.TriggerBotModule;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private static HudModule hud;
    private static NametagsModule nametags;
    private static CommandsModule commands;
    private static FriendsModule friends;

    public static void init() {
        // Yeni modülleri buraya ekle:
        register(new TriggerBotModule());
        register(new AimAssistModule());
        register(new AutoInventoryTotemModule());
        commands = new CommandsModule();
        friends = new FriendsModule();
        register(commands);
        register(new MacroModule());
        register(friends);
        // Misc modülleri varsayılan açık (config yüklenince kayıtlı durum geçerli olur).
        commands.setEnabled(true);
        friends.setEnabled(true);
        getByName("Macro").setEnabled(true);
        nametags = new NametagsModule();
        register(nametags);
        hud = new HudModule();
        register(hud);
    }

    private static void register(Module module) {
        MODULES.add(module);
    }

    public static NametagsModule nametags() { return nametags; }
    public static CommandsModule commands() { return commands; }
    public static FriendsModule friends() { return friends; }

    /** Büyük/küçük harf ve boşluk fark etmeksizin modül bulur. */
    public static Module getByName(String name) {
        String n = name.replace(" ", "");
        for (Module m : MODULES) {
            if (m.getName().equalsIgnoreCase(n)) return m;
        }
        return null;
    }

    public static List<Module> getModules() {
        return Collections.unmodifiableList(MODULES);
    }

    public static List<Module> getByCategory(Category category) {
        List<Module> out = new ArrayList<>();
        for (Module m : MODULES) {
            if (m.getCategory() == category) out.add(m);
        }
        return out;
    }

    /** Bind atanmış modülleri tuşa basılınca aç/kapat (sadece oyun içinde, ekran açık değilken). */
    public static void handleBinds(MinecraftClient mc) {
        long window = mc.getWindow().getHandle();
        for (Module m : MODULES) {
            int key = m.getKey();
            if (key < 0) {
                m.setKeyDown(false);
                continue;
            }
            boolean down = InputUtil.isKeyPressed(window, key);
            if (down && !m.isKeyDown() && mc.currentScreen == null) m.toggle();
            m.setKeyDown(down);
        }
    }

    public static void tick(MinecraftClient mc) {
        for (Module m : MODULES) {
            if (m.isEnabled()) m.onTick(mc);
        }
    }

    public static void renderHud(DrawContext ctx, MinecraftClient mc) {
        if (hud != null) hud.render(ctx, mc);
    }

    public static void renderWorld(WorldRenderContext ctx, MinecraftClient mc) {
        if (nametags != null) nametags.render(ctx, mc);
    }
}
