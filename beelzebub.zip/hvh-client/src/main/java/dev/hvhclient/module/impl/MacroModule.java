package dev.hvhclient.module.impl;

import dev.hvhclient.command.CommandManager;
import dev.hvhclient.macro.MacroManager;
import dev.hvhclient.module.Category;
import dev.hvhclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;

/** Makro tuşuna basınca kayıtlı mesajı sohbete / komutu sunucuya gönderir. */
public class MacroModule extends Module {
    public MacroModule() {
        super("Macro", Category.MISC);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null) return;
        long window = mc.getWindow().getHandle();

        for (MacroManager.Macro m : MacroManager.list()) {
            boolean pressed = InputUtil.isKeyPressed(window, m.key);
            if (pressed && !m.down && mc.currentScreen == null) run(p, m.message);
            m.down = pressed;
        }
    }

    private void run(ClientPlayerEntity p, String msg) {
        // Makro içinden client komutu da çalıştırılabilir (ör. ".toggle TriggerBot").
        if (CommandManager.handle(msg)) return;
        if (msg.startsWith("/")) {
            p.networkHandler.sendChatCommand(msg.substring(1));
        } else {
            p.networkHandler.sendChatMessage(msg);
        }
    }
}
