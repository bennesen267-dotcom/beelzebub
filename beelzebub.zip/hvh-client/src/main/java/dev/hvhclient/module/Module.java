package dev.hvhclient.module;

import dev.hvhclient.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    private final String name;
    private final Category category;
    private final List<Setting> settings = new ArrayList<>();
    private boolean enabled;
    private boolean expanded;
    private int key = -1;      // GLFW tuş kodu, -1 = bind yok
    private boolean keyDown;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    protected <T extends Setting> T add(T setting) {
        settings.add(setting);
        return setting;
    }

    public String getName() { return name; }
    public Category getCategory() { return category; }
    public List<Setting> getSettings() { return settings; }
    public boolean isEnabled() { return enabled; }
    public boolean isExpanded() { return expanded; }
    public void toggleExpanded() { expanded = !expanded; }

    public int getKey() { return key; }
    public void setKey(int key) { this.key = key; }
    public boolean isKeyDown() { return keyDown; }
    public void setKeyDown(boolean down) { this.keyDown = down; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean value) {
        if (value == enabled) return;
        enabled = value;
        if (enabled) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}

    /** Modül açıkken her tick çalışır. */
    public void onTick(MinecraftClient mc) {}
}
