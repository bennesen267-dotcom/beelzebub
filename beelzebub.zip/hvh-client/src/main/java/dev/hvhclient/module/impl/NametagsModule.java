package dev.hvhclient.module.impl;

import dev.hvhclient.friend.FriendManager;
import dev.hvhclient.module.Category;
import dev.hvhclient.module.Module;
import dev.hvhclient.setting.BoolSetting;
import dev.hvhclient.setting.SliderSetting;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/** Oyuncuların üstüne duvar arkasından da görünen, boyutu ayarlanabilir isim etiketi çizer. */
public class NametagsModule extends Module {
    /** Vanilla etiket ölçeği 0.025; Size 2 = vanilla boyutu. */
    private static final float UNIT = 0.0125f;

    private final SliderSetting size = add(new SliderSetting("Size", 1, 10, 3));
    private final BoolSetting health = add(new BoolSetting("Health", true));
    private final BoolSetting showSelf = add(new BoolSetting("Show Self", false));

    public NametagsModule() {
        super("Nametags", Category.RENDER);
    }

    public void render(WorldRenderContext ctx, MinecraftClient mc) {
        if (!isEnabled() || mc.world == null || mc.player == null || mc.options.hudHidden) return;

        Camera cam = ctx.camera();
        Vec3d camPos = cam.getPos();
        float td = ctx.tickDelta();
        TextRenderer tr = mc.textRenderer;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider.Immediate vc = mc.getBufferBuilders().getEntityVertexConsumers();

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p.isSpectator()) continue;
            if (p == mc.player && !(showSelf.get() && cam.isThirdPerson())) continue;

            double x = MathHelper.lerp(td, p.prevX, p.getX());
            double y = MathHelper.lerp(td, p.prevY, p.getY()) + p.getHeight() + 0.45;
            double z = MathHelper.lerp(td, p.prevZ, p.getZ());

            double dx = x - camPos.x, dy = y - camPos.y, dz = z - camPos.z;
            // Uzaktakiler de okunsun diye mesafeyle birlikte hafifçe büyür.
            float distScale = (float) Math.max(1.0, Math.sqrt(dx * dx + dy * dy + dz * dz) / 8.0);

            MutableText text = Text.literal(p.getGameProfile().getName())
                    .formatted(FriendManager.isFriend(p) ? Formatting.GREEN : Formatting.WHITE);
            if (health.get()) {
                float hp = p.getHealth() + p.getAbsorptionAmount();
                Formatting hpColor = hp > 14 ? Formatting.GREEN : hp > 7 ? Formatting.YELLOW : Formatting.RED;
                text.append(Text.literal(" " + Math.round(hp)).formatted(hpColor));
            }

            float s = UNIT * size.get() * distScale;
            ms.push();
            ms.translate(dx, dy, dz);
            ms.multiply(cam.getRotation());
            ms.scale(-s, -s, s);
            Matrix4f m = ms.peek().getPositionMatrix();
            float w = tr.getWidth(text);
            // SEE_THROUGH: duvarların arkasından da görünür; arka plan şeffaf siyah.
            tr.draw(text.asOrderedText(), -w / 2f, 0f, 0xFFFFFFFF, false, m, vc,
                    TextRenderer.TextLayerType.SEE_THROUGH, 0x66000000, LightmapTextureManager.MAX_LIGHT_COORDINATE);
            ms.pop();
        }
        vc.draw();
    }
}
