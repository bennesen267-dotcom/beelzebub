package dev.hvhclient.module.impl;

import dev.hvhclient.ClientMain;
import dev.hvhclient.module.Category;
import dev.hvhclient.module.Module;
import dev.hvhclient.module.ModuleManager;
import dev.hvhclient.setting.BoolSetting;
import dev.hvhclient.theme.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class HudModule extends Module {
    private final BoolSetting arrayList = add(new BoolSetting("ArrayList", true));
    private final BoolSetting watermark = add(new BoolSetting("Watermark", true));

    public HudModule() {
        super("HUD", Category.RENDER);
    }

    public void render(DrawContext ctx, MinecraftClient mc) {
        if (!isEnabled() || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int color = Theme.current().ui;

        if (watermark.get()) {
            ctx.drawTextWithShadow(tr, ClientMain.NAME, 4, 4, color);
        }

        if (arrayList.get()) {
            List<Module> active = new ArrayList<>();
            for (Module m : ModuleManager.getModules()) {
                if (m != this && m.isEnabled()) active.add(m);
            }
            active.sort(Comparator.comparingInt((Module m) -> tr.getWidth(m.getName())).reversed());

            int screenW = mc.getWindow().getScaledWidth();
            int y = 4;
            for (Module m : active) {
                String name = m.getName();
                ctx.drawTextWithShadow(tr, name, screenW - 4 - tr.getWidth(name), y, color);
                y += tr.fontHeight + 2;
            }
        }
    }
}
