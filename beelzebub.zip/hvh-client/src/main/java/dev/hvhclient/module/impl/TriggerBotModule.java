package dev.hvhclient.module.impl;

import dev.hvhclient.friend.FriendManager;
import dev.hvhclient.module.Category;
import dev.hvhclient.module.Module;
import dev.hvhclient.setting.BoolSetting;
import dev.hvhclient.setting.ModeSetting;
import dev.hvhclient.setting.MultiSetting;
import dev.hvhclient.setting.RangeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.registry.Registries;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.EntityHitResult;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class TriggerBotModule extends Module {
    private final BoolSetting onlyWeapons;
    private final MultiSetting weapons;
    private final ModeSetting mode;
    private final RangeSetting delay;
    private final BoolSetting whenUseHand;

    private long nextAttack;

    public TriggerBotModule() {
        super("TriggerBot", Category.COMBAT);

        // Oyundaki tüm itemler (bloklar dahil). Varsayılan seçili: kılıçlar ve baltalar.
        List<String> allItems = new ArrayList<>();
        List<String> defaults = new ArrayList<>();
        for (Item item : Registries.ITEM) {
            if (item == Items.AIR) continue;
            String id = Registries.ITEM.getId(item).toString();
            allItems.add(id);
            if (item instanceof SwordItem || item instanceof AxeItem) defaults.add(id);
        }

        onlyWeapons = add(new BoolSetting("Only Weapons", false));
        weapons = add(new MultiSetting("Weapons", allItems, defaults,
                id -> Registries.ITEM.get(new Identifier(id)).getName().getString()));
        mode = add(new ModeSetting("Mode", "Always",
                "Always", "Prioritize Crits", "Only Crits"));
        delay = add(new RangeSetting("Delay (ms)", 1, 500, 100, 150));
        whenUseHand = add(new BoolSetting("When Use Hand", false));
    }

    @Override
    protected void onEnable() {
        nextAttack = 0;
    }

    @Override
    public void onTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.interactionManager == null || mc.currentScreen != null) return;

        // When Use Hand kapalıyken: yemek/kalkan vb. kullanırken veya blok kırarken vurma.
        if (!whenUseHand.get() && (p.isUsingItem() || mc.interactionManager.isBreakingBlock())) return;

        if (!(mc.crosshairTarget instanceof EntityHitResult hit)) return;
        Entity target = hit.getEntity();
        if (!(target instanceof LivingEntity living) || !living.isAlive()) return;
        if (target instanceof ArmorStandEntity) return;
        if (FriendManager.isFriend(target)) return;

        if (onlyWeapons.get() && !holdingWeapon(p)) return;

        long now = System.currentTimeMillis();
        if (now < nextAttack) return;

        boolean critReady = canCrit(p);
        if (mode.is("Only Crits") && !critReady) return;
        // Prioritize: havada yükselirken bekle (düşüşte crit şansı doğar), yerdeyken/düşerken vur.
        if (mode.is("Prioritize Crits") && !critReady && !p.isOnGround() && p.getVelocity().y > 0) return;

        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);

        int lo = delay.getLo(), hi = delay.getHi();
        nextAttack = now + ThreadLocalRandom.current().nextInt(lo, hi + 1);
    }

    /** Vanilla crit koşulları + saldırı bekleme süresi dolmuş mu. */
    private boolean canCrit(ClientPlayerEntity p) {
        return p.getAttackCooldownProgress(0.5f) > 0.9f
                && p.fallDistance > 0.0f
                && !p.isOnGround()
                && !p.isClimbing()
                && !p.isTouchingWater()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)
                && !p.hasVehicle()
                && !p.isSprinting();
    }

    private boolean holdingWeapon(ClientPlayerEntity p) {
        Item item = p.getMainHandStack().getItem();
        return weapons.isSelected(Registries.ITEM.getId(item).toString());
    }
}
