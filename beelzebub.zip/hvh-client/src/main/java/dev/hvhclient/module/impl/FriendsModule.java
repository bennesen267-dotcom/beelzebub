package dev.hvhclient.module.impl;

import dev.hvhclient.config.ConfigManager;
import dev.hvhclient.friend.FriendManager;
import dev.hvhclient.module.Category;
import dev.hvhclient.module.Module;
import dev.hvhclient.setting.BoolSetting;
import dev.hvhclient.util.ChatUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;

/** Açıkken arkadaşlar TriggerBot/AimAssist hedefi olmaz. Orta tık ile arkadaş ekle/çıkar. */
public class FriendsModule extends Module {
    private final BoolSetting middleClick = add(new BoolSetting("Middle Click", true));
    private boolean mouseDown;

    public FriendsModule() {
        super("Friends", Category.MISC);
    }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player == null) return;
        boolean down = GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;

        if (down && !mouseDown && middleClick.get() && mc.currentScreen == null
                && mc.crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof PlayerEntity target && target != mc.player) {
            String name = target.getGameProfile().getName();
            if (FriendManager.has(name)) {
                FriendManager.remove(name);
                ChatUtil.info(name + " arkadaşlardan çıkarıldı.");
            } else {
                FriendManager.add(name);
                ChatUtil.info(name + " arkadaş olarak eklendi.");
            }
            ConfigManager.save();
        }
        mouseDown = down;
    }
}
