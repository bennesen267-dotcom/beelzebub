package dev.hvhclient.module.impl;

import dev.hvhclient.module.Category;
import dev.hvhclient.module.Module;
import dev.hvhclient.setting.ModeSetting;

/** Sohbette prefix ile yazılan client komutlarını açar (ör. .friend add isim). */
public class CommandsModule extends Module {
    private final ModeSetting prefix = add(new ModeSetting("Prefix", ".", ".", ",", "$", "-", ";"));

    public CommandsModule() {
        super("Commands", Category.MISC);
    }

    public String prefix() {
        return prefix.get();
    }
}
