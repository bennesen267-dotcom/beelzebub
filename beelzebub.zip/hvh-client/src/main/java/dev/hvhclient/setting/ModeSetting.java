package dev.hvhclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.List;

public class ModeSetting extends Setting {
    private final List<String> modes;
    private int index;

    public ModeSetting(String name, String def, String... modes) {
        super(name);
        this.modes = List.of(modes);
        this.index = Math.max(0, this.modes.indexOf(def));
    }

    public String get() { return modes.get(index); }
    public boolean is(String mode) { return get().equals(mode); }
    public void next() { index = (index + 1) % modes.size(); }
    public void prev() { index = (index - 1 + modes.size()) % modes.size(); }

    @Override
    public JsonElement save() { return new JsonPrimitive(get()); }

    @Override
    public void load(JsonElement json) {
        if (!json.isJsonPrimitive()) return;
        int i = modes.indexOf(json.getAsString());
        if (i >= 0) index = i;
    }
}
