package dev.hvhclient.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/** İki noktalı slider (alt - üst değer). */
public class RangeSetting extends Setting {
    private final int min, max;
    private int lo, hi;

    public RangeSetting(String name, int min, int max, int defLo, int defHi) {
        super(name);
        this.min = min;
        this.max = max;
        this.lo = Math.max(min, Math.min(defLo, defHi));
        this.hi = Math.min(max, Math.max(defLo, defHi));
    }

    public int getMin() { return min; }
    public int getMax() { return max; }
    public int getLo() { return lo; }
    public int getHi() { return hi; }

    public void setLo(int v) { lo = Math.max(min, Math.min(v, hi)); }
    public void setHi(int v) { hi = Math.min(max, Math.max(v, lo)); }

    @Override
    public JsonElement save() {
        JsonObject o = new JsonObject();
        o.addProperty("lo", lo);
        o.addProperty("hi", hi);
        return o;
    }

    @Override
    public void load(JsonElement json) {
        if (!json.isJsonObject()) return;
        JsonObject o = json.getAsJsonObject();
        if (!o.has("lo") || !o.has("hi")) return;
        int a = o.get("lo").getAsInt(), b = o.get("hi").getAsInt();
        lo = Math.max(min, Math.min(Math.min(a, b), max));
        hi = Math.min(max, Math.max(Math.max(a, b), min));
    }
}
