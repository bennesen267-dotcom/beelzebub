package dev.hvhclient.mixin;

import dev.hvhclient.module.ModuleManager;
import dev.hvhclient.module.impl.NametagsModule;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Nametags açıkken vanilla oyuncu etiketini gizler (çift etiket olmasın). */
@Mixin(LivingEntityRenderer.class)
public class LivingEntityRendererMixin {
    @Inject(method = "hasLabel(Lnet/minecraft/entity/LivingEntity;)Z", at = @At("HEAD"), cancellable = true)
    private void beelzebub$hideVanillaNametag(LivingEntity entity, CallbackInfoReturnable<Boolean> cir) {
        NametagsModule nt = ModuleManager.nametags();
        if (nt != null && nt.isEnabled() && entity instanceof PlayerEntity) {
            cir.setReturnValue(false);
        }
    }
}
