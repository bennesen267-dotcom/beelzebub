package dev.hvhclient.macro;

import net.minecraft.client.util.InputUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Tuşa bağlı sohbet mesajı / komut makroları. */
public class MacroManager {
    public static class Macro {
        public final String name;
        public final int key;
        public final String message;
        public boolean down;

        public Macro(String name, int key, String message) {
            this.name = name;
            this.key = key;
            this.message = message;
        }
    }

    private static final List<Macro> MACROS = new ArrayList<>();

    public static List<Macro> list() {
        return Collections.unmodifiableList(MACROS);
    }

    /** Aynı isimde makro varsa üzerine yazar. */
    public static void add(String name, int key, String message) {
        remove(name);
        MACROS.add(new Macro(name, key, message));
    }

    public static boolean remove(String name) {
        return MACROS.removeIf(m -> m.name.equalsIgnoreCase(name));
    }

    public static void clear() {
        MACROS.clear();
    }

    /** "g", "f6", "left.shift", "keypad.1" gibi isimleri GLFW tuş koduna çevirir. -1 = geçersiz. */
    public static int parseKey(String name) {
        try {
            return InputUtil.fromTranslationKey("key.keyboard." + name.toLowerCase().replace(' ', '.')).getCode();
        } catch (IllegalArgumentException e) {
            return -1;
        }
    }

    public static String keyName(int code) {
        return InputUtil.fromKeyCode(code, -1).getLocalizedText().getString();
    }
}
