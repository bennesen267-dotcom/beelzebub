package dev.hvhclient;

import dev.hvhclient.config.ConfigManager;
import dev.hvhclient.gui.ClickGuiScreen;
import dev.hvhclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import dev.hvhclient.command.CommandManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ClientMain implements ClientModInitializer {
    public static final String NAME = "Beelzebub";

    private static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ConfigManager.load();

        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "ClickGUI", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, NAME));

        // Prefix ile başlayan komutları yakala; yakalananlar sunucuya gitmez.
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> !CommandManager.handle(msg));

        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> ConfigManager.save());
        HudRenderCallback.EVENT.register((ctx, tickDelta) ->
                ModuleManager.renderHud(ctx, MinecraftClient.getInstance()));

        WorldRenderEvents.LAST.register(ctx ->
                ModuleManager.renderWorld(ctx, MinecraftClient.getInstance()));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new ClickGuiScreen());
            }
            if (mc.player != null && mc.world != null) {
                ModuleManager.handleBinds(mc);
                ModuleManager.tick(mc);
            }
        });
    }
}
