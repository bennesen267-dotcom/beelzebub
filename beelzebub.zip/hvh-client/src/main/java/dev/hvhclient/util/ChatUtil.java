package dev.hvhclient.util;

import dev.hvhclient.ClientMain;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Sohbete sadece client tarafında görünen mesaj yazar (sunucuya gitmez). */
public class ChatUtil {
    public static void info(String message) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud == null) return;
        Text text = Text.literal("[" + ClientMain.NAME + "] ").formatted(Formatting.LIGHT_PURPLE)
                .append(Text.literal(message).formatted(Formatting.GRAY));
        mc.inGameHud.getChatHud().addMessage(text);
    }
}
