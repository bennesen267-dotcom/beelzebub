package dev.hvhclient.friend;

import dev.hvhclient.module.ModuleManager;
import dev.hvhclient.module.impl.FriendsModule;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Arkadaş listesi. İsimler küçük harfe çevrilerek karşılaştırılır. */
public class FriendManager {
    // küçük harf -> yazıldığı hali
    private static final Map<String, String> FRIENDS = new LinkedHashMap<>();

    private static String key(String name) {
        return name.toLowerCase(Locale.ROOT);
    }

    public static boolean add(String name) {
        return FRIENDS.putIfAbsent(key(name), name) == null;
    }

    public static boolean remove(String name) {
        return FRIENDS.remove(key(name)) != null;
    }

    public static boolean has(String name) {
        return FRIENDS.containsKey(key(name));
    }

    public static void clear() {
        FRIENDS.clear();
    }

    public static List<String> list() {
        return new ArrayList<>(FRIENDS.values());
    }

    /** Friends modülü açıkken, arkadaş olan oyunculara saldırı/aim yapılmaz. */
    public static boolean isFriend(Entity e) {
        if (!(e instanceof PlayerEntity p)) return false;
        FriendsModule m = ModuleManager.friends();
        if (m == null || !m.isEnabled()) return false;
        return has(p.getGameProfile().getName());
    }
}
