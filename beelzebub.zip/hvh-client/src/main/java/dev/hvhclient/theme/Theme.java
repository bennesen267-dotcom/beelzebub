package dev.hvhclient.theme;

public enum Theme {
    //                 isim          accent      yazı(accent üstü)  ui (küçük öğeler/yazı)
    YELLOW("Sarı",        0xFFFFD500, 0xFF000000, 0xFFFFD500),
    WHITE("Beyaz",        0xFFFFFFFF, 0xFF000000, 0xFFFFFFFF),
    BLACK("Siyah",        0xFF000000, 0xFFFFFFFF, 0xFFB0B0B0),
    PURPLE("Mor",         0xFF9B30FF, 0xFFFFFFFF, 0xFFB565FF),
    BLUE("Mavi",          0xFF1E90FF, 0xFFFFFFFF, 0xFF1E90FF),
    RED("Kırmızı",        0xFFE02020, 0xFFFFFFFF, 0xFFFF4040),
    DARK_BLUE("Koyu Mavi", 0xFF0A2A8A, 0xFFFFFFFF, 0xFF3D63D6);

    public final String label;
    /** Büyük dolgular (başlık, açık modül). */
    public final int accent;
    /** Accent üzerindeki yazı rengi. */
    public final int onAccent;
    /** Koyu arka plan üzerinde okunur vurgu rengi (slider, checkbox, değerler). */
    public final int ui;

    Theme(String label, int accent, int onAccent, int ui) {
        this.label = label;
        this.accent = accent;
        this.onAccent = onAccent;
        this.ui = ui;
    }

    private static Theme current = Theme.PURPLE;

    public static Theme current() { return current; }
    public static void set(Theme theme) { current = theme; }
}
