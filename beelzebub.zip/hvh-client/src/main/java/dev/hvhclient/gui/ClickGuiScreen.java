package dev.hvhclient.gui;

import dev.hvhclient.ClientMain;
import dev.hvhclient.config.ConfigManager;
import dev.hvhclient.module.Category;
import dev.hvhclient.module.Module;
import dev.hvhclient.module.ModuleManager;
import dev.hvhclient.setting.BoolSetting;
import dev.hvhclient.setting.ModeSetting;
import dev.hvhclient.setting.MultiSetting;
import dev.hvhclient.setting.RangeSetting;
import dev.hvhclient.setting.Setting;
import dev.hvhclient.setting.SliderSetting;
import dev.hvhclient.theme.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
    private static final int W = 300, H = 270;
    private static final int TITLE_H = 22, TAB_H = 20, BOTTOM_H = 28;
    private static final int MOD_H = 20, SET_H = 18, RANGE_H = 32, OPT_H = 16, GAP = 2;
    private static final int SW = 12, SW_GAP = 5;

    private enum Kind { MODULE, BOOL, MODE, RANGE, SLIDER, MULTI, SEARCH, OPTION }

    private record Row(Kind kind, Module module, Setting setting, String option, int y, int h) {}

    private static Category selected = Category.COMBAT;

    private final List<Row> rows = new ArrayList<>();
    private int x, y, scroll, cursor, contentH;
    private RangeSetting dragRange;
    private boolean dragHi;
    private MultiSetting focusedSearch;
    private SliderSetting dragSlider;
    private Module bindingModule;

    public ClickGuiScreen() {
        super(Text.literal("ClickGUI"));
    }

    @Override
    protected void init() {
        x = (width - W) / 2;
        y = (height - H) / 2;
    }

    @Override
    public void removed() {
        ConfigManager.save();
        super.removed();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    // ---------- yerleşim ----------
    private int tabY() { return y + TITLE_H; }
    private int viewTop() { return y + TITLE_H + TAB_H + 4; }
    private int viewBottom() { return y + H - BOTTOM_H; }
    private int viewH() { return viewBottom() - viewTop(); }
    private int rowX() { return x + 6; }
    private int rowW() { return W - 16; }
    private int trackX() { return x + 22; }
    private int trackW() { return W - 40; }
    private int swatchStartX() {
        int n = Theme.values().length;
        return x + W - 8 - (n * SW + (n - 1) * SW_GAP);
    }
    private int swatchY() { return viewBottom() + (BOTTOM_H - SW) / 2; }

    private static boolean inside(double mx, double my, int x1, int y1, int x2, int y2) {
        return mx >= x1 && mx < x2 && my >= y1 && my < y2;
    }

    private void addRow(Kind kind, Module m, Setting s, String opt, int h) {
        rows.add(new Row(kind, m, s, opt, cursor, h));
        cursor += h + GAP;
    }

    private void buildRows() {
        rows.clear();
        cursor = 0;
        for (Module m : ModuleManager.getByCategory(selected)) {
            addRow(Kind.MODULE, m, null, null, MOD_H);
            if (!m.isExpanded()) continue;
            for (Setting s : m.getSettings()) {
                if (s instanceof BoolSetting) {
                    addRow(Kind.BOOL, m, s, null, SET_H);
                } else if (s instanceof ModeSetting) {
                    addRow(Kind.MODE, m, s, null, SET_H);
                } else if (s instanceof RangeSetting) {
                    addRow(Kind.RANGE, m, s, null, RANGE_H);
                } else if (s instanceof SliderSetting) {
                    addRow(Kind.SLIDER, m, s, null, RANGE_H);
                } else if (s instanceof MultiSetting ms) {
                    addRow(Kind.MULTI, m, s, null, SET_H);
                    if (ms.isOpen()) {
                        addRow(Kind.SEARCH, m, s, null, SET_H);
                        for (String opt : ms.getOptions()) {
                            if (ms.matches(opt)) addRow(Kind.OPTION, m, s, opt, OPT_H);
                        }
                    }
                }
            }
            cursor += 4;
        }
        contentH = cursor;
        scroll = Math.max(0, Math.min(scroll, contentH - viewH()));
    }

    // ---------- çizim ----------
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);
        buildRows();
        Theme t = Theme.current();

        // pencere + başlık
        ctx.fill(x, y, x + W, y + H, 0xE6141414);
        ctx.drawBorder(x - 1, y - 1, W + 2, H + 2, t.ui);
        ctx.fill(x, y, x + W, y + TITLE_H, t.accent);
        ctx.drawText(textRenderer, ClientMain.NAME, x + 8, y + 7, t.onAccent, false);
        String hint = "Sağ tık: ayarlar | Orta tık: bind";
        ctx.drawText(textRenderer, hint, x + W - 8 - textRenderer.getWidth(hint), y + 7, t.onAccent, false);

        // sekmeler
        Category[] cats = Category.values();
        int tabW = W / cats.length;
        for (int i = 0; i < cats.length; i++) {
            int tx = x + i * tabW;
            boolean sel = cats[i] == selected;
            ctx.fill(tx, tabY(), tx + tabW, tabY() + TAB_H, sel ? 0xFF2A2A2A : 0xFF1C1C1C);
            if (sel) ctx.fill(tx, tabY() + TAB_H - 2, tx + tabW, tabY() + TAB_H, t.ui);
            ctx.drawCenteredTextWithShadow(textRenderer, cats[i].label, tx + tabW / 2,
                    tabY() + 6, sel ? 0xFFFFFFFF : 0xFF888888);
        }

        // satırlar (kaydırılabilir alan)
        if (rows.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, "Henüz modül yok",
                    x + W / 2, viewTop() + 20, 0xFF666666);
        }
        ctx.enableScissor(x, viewTop(), x + W, viewBottom());
        for (Row r : rows) {
            int ry = viewTop() + r.y() - scroll;
            if (ry + r.h() < viewTop() || ry > viewBottom()) continue;
            drawRow(ctx, r, ry, mouseX, mouseY, t);
        }
        ctx.disableScissor();

        // scrollbar
        if (contentH > viewH()) {
            int barH = Math.max(12, viewH() * viewH() / contentH);
            int barY = viewTop() + (int) ((long) scroll * (viewH() - barH) / (contentH - viewH()));
            ctx.fill(x + W - 5, barY, x + W - 2, barY + barH, 0xFF555555);
        }

        // alt bar: tema seçici
        ctx.fill(x, viewBottom(), x + W, y + H, 0xFF101010);
        ctx.drawText(textRenderer, "Tema", x + 8, viewBottom() + 10, 0xFFAAAAAA, false);
        Theme[] themes = Theme.values();
        for (int i = 0; i < themes.length; i++) {
            int sx = swatchStartX() + i * (SW + SW_GAP);
            int sy = swatchY();
            boolean sel = themes[i] == t;
            ctx.fill(sx - 1, sy - 1, sx + SW + 1, sy + SW + 1, sel ? 0xFFFFFFFF : 0xFF444444);
            ctx.fill(sx, sy, sx + SW, sy + SW, themes[i].accent);
            if (inside(mouseX, mouseY, sx, sy, sx + SW, sy + SW)) {
                ctx.drawText(textRenderer, themes[i].label, x + 45, viewBottom() + 10, 0xFFFFFFFF, false);
            }
        }

        super.render(ctx, mouseX, mouseY, delta);
    }

    private void checkbox(DrawContext ctx, int cx, int cy, boolean on, Theme t) {
        ctx.fill(cx, cy, cx + 10, cy + 10, 0xFF555555);
        ctx.fill(cx + 1, cy + 1, cx + 9, cy + 9, on ? t.ui : 0xFF1A1A1A);
    }

    private static String keyName(int key) {
        return InputUtil.fromKeyCode(key, -1).getLocalizedText().getString().toUpperCase();
    }

    private int valueX(int value, int min, int max) {
        double frac = (double) (value - min) / (max - min);
        return trackX() + (int) Math.round(frac * trackW());
    }

    private int handleX(RangeSetting rs, int value) {
        double frac = (double) (value - rs.getMin()) / (rs.getMax() - rs.getMin());
        return trackX() + (int) Math.round(frac * trackW());
    }

    private void drawRow(DrawContext ctx, Row r, int ry, int mx, int my, Theme t) {
        int rx = rowX();
        int rw = rowW();
        int sx = rx + 8;       // ayar satırı başlangıcı
        int sw = rw - 8;
        int h = r.h();

        switch (r.kind()) {
            case MODULE -> {
                Module m = r.module();
                boolean hover = inside(mx, my, rx, ry, rx + rw, ry + h);
                int bg = m.isEnabled() ? t.accent : (hover ? 0xFF2A2A2A : 0xFF1E1E1E);
                int fg = m.isEnabled() ? t.onAccent : 0xFFFFFFFF;
                int dim = m.isEnabled() ? t.onAccent : 0xFF777777;
                ctx.fill(rx, ry, rx + rw, ry + h, bg);
                ctx.drawText(textRenderer, m.getName(), rx + 8, ry + 6, fg, false);
                if (!m.getSettings().isEmpty()) {
                    ctx.drawText(textRenderer, m.isExpanded() ? "v" : ">",
                            rx + 8 + textRenderer.getWidth(m.getName()) + 5, ry + 6, dim, false);
                }
                String state = m.isEnabled() ? "ON" : "OFF";
                ctx.drawText(textRenderer, state, rx + rw - 8 - textRenderer.getWidth(state), ry + 6, dim, false);
                String bind = m == bindingModule ? "[...]"
                        : (m.getKey() >= 0 ? "[" + keyName(m.getKey()) + "]" : "");
                if (!bind.isEmpty()) {
                    ctx.drawText(textRenderer, bind,
                            rx + rw - 8 - textRenderer.getWidth(state) - 6 - textRenderer.getWidth(bind),
                            ry + 6, dim, false);
                }
            }
            case BOOL -> {
                BoolSetting b = (BoolSetting) r.setting();
                boolean hover = inside(mx, my, sx, ry, sx + sw, ry + h);
                ctx.fill(sx, ry, sx + sw, ry + h, hover ? 0xFF222222 : 0xFF1A1A1A);
                ctx.drawText(textRenderer, b.getName(), sx + 6, ry + 5, 0xFFDDDDDD, false);
                checkbox(ctx, sx + sw - 16, ry + 4, b.get(), t);
            }
            case MODE -> {
                ModeSetting ms = (ModeSetting) r.setting();
                boolean hover = inside(mx, my, sx, ry, sx + sw, ry + h);
                ctx.fill(sx, ry, sx + sw, ry + h, hover ? 0xFF222222 : 0xFF1A1A1A);
                ctx.drawText(textRenderer, ms.getName(), sx + 6, ry + 5, 0xFFDDDDDD, false);
                String v = ms.get();
                ctx.drawText(textRenderer, v, sx + sw - 6 - textRenderer.getWidth(v), ry + 5, t.ui, false);
            }
            case RANGE -> {
                RangeSetting rs = (RangeSetting) r.setting();
                ctx.fill(sx, ry, sx + sw, ry + h, 0xFF1A1A1A);
                ctx.drawText(textRenderer, rs.getName(), sx + 6, ry + 5, 0xFFDDDDDD, false);
                String v = rs.getLo() + " - " + rs.getHi();
                ctx.drawText(textRenderer, v, sx + sw - 6 - textRenderer.getWidth(v), ry + 5, t.ui, false);
                int tx = trackX(), tw = trackW(), ty = ry + 21;
                int plo = handleX(rs, rs.getLo());
                int phi = handleX(rs, rs.getHi());
                ctx.fill(tx, ty, tx + tw, ty + 4, 0xFF3A3A3A);
                ctx.fill(plo, ty, phi, ty + 4, t.ui);
                ctx.fill(plo - 3, ty - 3, plo + 3, ty + 7, 0xFFFFFFFF);
                ctx.fill(phi - 3, ty - 3, phi + 3, ty + 7, 0xFFFFFFFF);
            }
            case SLIDER -> {
                SliderSetting ss = (SliderSetting) r.setting();
                ctx.fill(sx, ry, sx + sw, ry + h, 0xFF1A1A1A);
                ctx.drawText(textRenderer, ss.getName(), sx + 6, ry + 5, 0xFFDDDDDD, false);
                String v = ss.display();
                ctx.drawText(textRenderer, v, sx + sw - 6 - textRenderer.getWidth(v), ry + 5, t.ui, false);
                int tx = trackX(), tw = trackW(), ty = ry + 21;
                int px = valueX(ss.get(), ss.getMin(), ss.getMax());
                ctx.fill(tx, ty, tx + tw, ty + 4, 0xFF3A3A3A);
                ctx.fill(tx, ty, px, ty + 4, t.ui);
                ctx.fill(px - 3, ty - 3, px + 3, ty + 7, 0xFFFFFFFF);
            }
            case MULTI -> {
                MultiSetting ms = (MultiSetting) r.setting();
                boolean hover = inside(mx, my, sx, ry, sx + sw, ry + h);
                ctx.fill(sx, ry, sx + sw, ry + h, hover ? 0xFF222222 : 0xFF1A1A1A);
                ctx.drawText(textRenderer, ms.getName(), sx + 6, ry + 5, 0xFFDDDDDD, false);
                String v = ms.selectedCount() + "/" + ms.getOptions().size() + (ms.isOpen() ? " v" : " >");
                ctx.drawText(textRenderer, v, sx + sw - 6 - textRenderer.getWidth(v), ry + 5, t.ui, false);
            }
            case SEARCH -> {
                MultiSetting ms = (MultiSetting) r.setting();
                boolean focused = ms == focusedSearch;
                String q = ms.getSearch();
                ctx.fill(sx + 8, ry, sx + sw, ry + h, 0xFF161616);
                ctx.drawBorder(sx + 8, ry, sw - 8, h, focused ? t.ui : 0xFF444444);
                boolean placeholder = q.isEmpty() && !focused;
                String shown = placeholder ? "Ara..."
                        : q + (focused && (System.currentTimeMillis() / 500) % 2 == 0 ? "_" : "");
                ctx.drawText(textRenderer, shown, sx + 14, ry + 5, placeholder ? 0xFF666666 : 0xFFFFFFFF, false);
            }
            case OPTION -> {
                MultiSetting ms = (MultiSetting) r.setting();
                boolean hover = inside(mx, my, sx + 8, ry, sx + sw, ry + h);
                ctx.fill(sx + 8, ry, sx + sw, ry + h, hover ? 0xFF202020 : 0xFF161616);
                ctx.drawText(textRenderer, ms.label(r.option()), sx + 14, ry + 4, 0xFFCCCCCC, false);
                checkbox(ctx, sx + sw - 16, ry + 3, ms.isSelected(r.option()), t);
            }
        }
    }

    // ---------- girdi ----------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0 && button != 1 && button != 2) return super.mouseClicked(mx, my, button);
        buildRows();
        focusedSearch = null;
        bindingModule = null;

        // orta tık: modüle bind atamayı başlat
        if (button == 2) {
            if (inside(mx, my, rowX(), viewTop(), rowX() + rowW(), viewBottom())) {
                for (Row r : rows) {
                    int ry = viewTop() + r.y() - scroll;
                    if (r.kind() == Kind.MODULE && my >= ry && my < ry + r.h()) {
                        bindingModule = r.module();
                        break;
                    }
                }
            }
            return true;
        }

        // sekmeler
        if (button == 0) {
            Category[] cats = Category.values();
            int tabW = W / cats.length;
            for (int i = 0; i < cats.length; i++) {
                int tx = x + i * tabW;
                if (inside(mx, my, tx, tabY(), tx + tabW, tabY() + TAB_H)) {
                    selected = cats[i];
                    scroll = 0;
                    return true;
                }
            }

            // tema renkleri
            Theme[] themes = Theme.values();
            for (int i = 0; i < themes.length; i++) {
                int sx = swatchStartX() + i * (SW + SW_GAP);
                if (inside(mx, my, sx, swatchY(), sx + SW, swatchY() + SW)) {
                    Theme.set(themes[i]);
                    return true;
                }
            }
        }

        // satırlar
        if (inside(mx, my, rowX(), viewTop(), rowX() + rowW(), viewBottom())) {
            for (Row r : rows) {
                int ry = viewTop() + r.y() - scroll;
                if (my >= ry && my < ry + r.h()) {
                    handleClick(r, mx, button);
                    return true;
                }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    private void handleClick(Row r, double mx, int button) {
        switch (r.kind()) {
            case MODULE -> {
                if (button == 0) r.module().toggle();
                else if (!r.module().getSettings().isEmpty()) r.module().toggleExpanded();
            }
            case BOOL -> ((BoolSetting) r.setting()).toggle();
            case MODE -> {
                ModeSetting ms = (ModeSetting) r.setting();
                if (button == 1) ms.prev(); else ms.next();
            }
            case RANGE -> {
                if (button != 0) return;
                dragRange = (RangeSetting) r.setting();
                double plo = handleX(dragRange, dragRange.getLo());
                double phi = handleX(dragRange, dragRange.getHi());
                double dlo = Math.abs(mx - plo), dhi = Math.abs(mx - phi);
                dragHi = dhi < dlo || (dhi == dlo && mx > plo);
                updateDrag(mx);
            }
            case SLIDER -> {
                if (button != 0) return;
                dragSlider = (SliderSetting) r.setting();
                updateSliderDrag(mx);
            }
            case MULTI -> ((MultiSetting) r.setting()).toggleOpen();
            case SEARCH -> focusedSearch = (MultiSetting) r.setting();
            case OPTION -> ((MultiSetting) r.setting()).toggle(r.option());
        }
    }

    private void updateSliderDrag(double mx) {
        if (dragSlider == null) return;
        double frac = Math.max(0, Math.min(1, (mx - trackX()) / trackW()));
        dragSlider.set((int) Math.round(dragSlider.getMin() + frac * (dragSlider.getMax() - dragSlider.getMin())));
    }

    private void updateDrag(double mx) {
        if (dragRange == null) return;
        double frac = Math.max(0, Math.min(1, (mx - trackX()) / trackW()));
        int v = (int) Math.round(dragRange.getMin() + frac * (dragRange.getMax() - dragRange.getMin()));
        if (dragHi) dragRange.setHi(v); else dragRange.setLo(v);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragRange != null) {
            updateDrag(mx);
            return true;
        }
        if (dragSlider != null) {
            updateSliderDrag(mx);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragRange = null;
        dragSlider = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        scroll -= (int) (amount * 14);
        scroll = Math.max(0, Math.min(scroll, Math.max(0, contentH - viewH())));
        return true;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (focusedSearch != null && chr >= ' ' && chr != 127) {
            String q = focusedSearch.getSearch();
            if (q.length() < 32) focusedSearch.setSearch(q + chr);
            return true;
        }
        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // bind atama modu: Esc iptal, Backspace/Delete bind'i siler, diğer tuş bind olur
        if (bindingModule != null) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE || keyCode == GLFW.GLFW_KEY_DELETE) {
                bindingModule.setKey(-1);
            } else if (keyCode != GLFW.GLFW_KEY_ESCAPE) {
                bindingModule.setKey(keyCode);
            }
            bindingModule = null;
            return true;
        }
        if (focusedSearch != null) {
            if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
                String q = focusedSearch.getSearch();
                if (!q.isEmpty()) focusedSearch.setSearch(q.substring(0, q.length() - 1));
                return true;
            }
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                focusedSearch = null;
                return true;
            }
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
